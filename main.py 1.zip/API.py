import uvicorn
from fastapi import FastAPI, HTTPException
import py_functions
import config
import pyodbc
import logging
import json
from contextlib import contextmanager

logging.basicConfig(level=logging.DEBUG)

app = FastAPI()


@contextmanager
def get_db_connection(pwd: str):
    """Context manager to handle database connection and closing."""
    driver = config.DRIVER
    server = config.SERVER
    database = config.DATABASE
    uid = config.UID
    con_string = f'DRIVER={driver};SERVER={server};DATABASE={database};UID={uid};PWD={pwd}'

    cnxn = None
    cursor = None
    try:
        logging.info(f'Attempting to connect to the database: {server}')
        cnxn = pyodbc.connect(con_string)
        cnxn.autocommit = True
        cursor = cnxn.cursor()
        logging.info("Connection successful with the database")
        yield cnxn, cursor
    except Exception as e:
        logging.error("Database connection failed:", e)
        raise HTTPException(status_code=500, detail="Database connection failed")
    finally:
        if cnxn:
            cnxn.close()
            logging.info("Database connection closed")


@app.get('/')
def get_data(search: str = ""):
    try:
        logging.info(f'Fetching data with search: {search}')
        with get_db_connection(config.PASSWORD) as (cnxn, cursor):
            df = py_functions.fetch_data(search, cnxn)
            return df.to_dict("records")
    except Exception as e:
        logging.error(f'Error fetching data: {e}')
        raise HTTPException(status_code=500, detail='Internal server error while fetching data')


@app.post('/signup/')
def signup(firstname: str, lastname: str, city: str, email: str, password: str):
    try:
        logging.info(f'Received signup data: firstname={firstname}, lastname={lastname}, city={city}, email={email}')
        if '@gmail.com' not in email:
            raise HTTPException(status_code=400, detail="Invalid email format")
        
        with get_db_connection(config.PASSWORD) as (cnxn, cursor):
            logging.info(f'Checking if user with email {email} exists')
            user_exist = py_functions.check_user_exists(email, cnxn)
            if user_exist:
                raise HTTPException(status_code=400, detail="Email ID already exists.")
            
            logging.info(f'Signing up user: {email}')
            signup_query = py_functions.signup_data(firstname, lastname, city, email, password)
            logging.debug(f'Signup query: {signup_query}')
            cursor.execute(signup_query)
            cnxn.commit()

            return {"status": "signed up. Please login with same credentials."}
    except Exception as e:
        logging.error(f'Error during signup: {e}')
        raise HTTPException(status_code=500, detail='Internal server error during signup')


@app.post('/login/')
def login(email: str, password: str):
    try:
        logging.info(f'Attempting to login with email {email}')
        with get_db_connection(config.PASSWORD) as (cnxn, cursor):
            user_exist = py_functions.check_user_details(email, password, cnxn)
            if user_exist > 0:
                return {"status": "Login successful, access granted"}
            else:
                raise HTTPException(status_code=401, detail="Invalid credentials. Access cannot be granted.")
    except Exception as e:
        logging.error(f'Error during login: {e}')
        raise HTTPException(status_code=500, detail='Internal server error during login')


if __name__ == "__main__":
    uvicorn.run(app, host='127.0.0.1', port=8100)